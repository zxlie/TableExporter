function e(){let e=document.querySelector(".navbar"),t=document.querySelector(".nav-toggle"),o=document.querySelector(".nav-menu");window.addEventListener("scroll",function(){100<window.scrollY?(e.style.background="rgba(255, 255, 255, 0.98)",e.style.boxShadow="0 2px 20px rgba(0, 0, 0, 0.1)"):(e.style.background="rgba(255, 255, 255, 0.95)",e.style.boxShadow="none")}),t&&t.addEventListener("click",function(){o.classList.toggle("active"),t.classList.toggle("active")}),document.querySelectorAll(".nav-link").forEach(e=>{e.addEventListener("click",function(){o.classList.contains("active")&&(o.classList.remove("active"),t.classList.remove("active"))})})}function t(){let t=document.querySelectorAll(".demo-tab"),o=document.querySelectorAll(".demo-panel");t.forEach(e=>{e.addEventListener("click",function(){var e=this.getAttribute("data-tab");t.forEach(e=>e.classList.remove("active")),o.forEach(e=>e.classList.remove("active")),this.classList.add("active"),document.getElementById(e).classList.add("active")})}),document.querySelectorAll(".export-btn").forEach(e=>{e.addEventListener("click",function(e){e.preventDefault();let t=this.innerHTML;this.innerHTML='<i class="fas fa-spinner fa-spin"></i> 正在导出...',this.style.opacity="0.7",this.style.pointerEvents="none",setTimeout(()=>{this.innerHTML='<i class="fas fa-check"></i> 导出成功！',setTimeout(()=>{this.innerHTML=t,this.style.opacity="1",this.style.pointerEvents="auto"},1500)},2e3),s("演示：表格导出功能已触发！实际使用中会下载Excel文件。","success")})})}function o(){let o=document.querySelectorAll(".faq-item");o.forEach(t=>{t.querySelector(".faq-question").addEventListener("click",function(){var e=t.classList.contains("active");o.forEach(e=>{e!==t&&e.classList.remove("active")}),e?t.classList.remove("active"):t.classList.add("active")})})}function n(){var e={threshold:.1,rootMargin:"0px 0px -50px 0px"};let t=new IntersectionObserver(function(e){e.forEach(e=>{e.isIntersecting&&e.target.classList.add("animate")})},e);document.querySelectorAll(".feature-card, .step-item, .faq-item, .hero-text, .hero-image").forEach(e=>{e.classList.add("fade-in-up"),t.observe(e)});var o=document.querySelectorAll(".stat-number");let n=new IntersectionObserver(function(e){e.forEach(e=>{e.isIntersecting&&(a(e.target),n.unobserve(e.target))})},e);o.forEach(e=>{n.observe(e)})}function a(n){var e=n.textContent;let a=parseInt(e.replace(/\D/g,"")),i=e.replace(/[\d,]/g,"");if(!isNaN(a)){let e=a/125,t=0,o=setInterval(()=>{(t+=e)>=a&&(t=a,clearInterval(o)),i.includes("%")?n.textContent=Math.floor(t)+"%":i.includes("K")?n.textContent=Math.floor(t/1e3)+"K+":n.textContent=Math.floor(t).toLocaleString()+i},16)}}function i(){let e=document.getElementById("backToTop");window.addEventListener("scroll",function(){300<window.scrollY?e.classList.add("show"):e.classList.remove("show")}),e.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"})})}function r(){document.querySelectorAll('a[href^="#"]').forEach(e=>{e.addEventListener("click",function(e){e.preventDefault();var e=this.getAttribute("href"),e=document.querySelector(e);e&&(e=e.offsetTop-80,window.scrollTo({top:e,behavior:"smooth"}))})})}function s(e,t="info"){let o=document.createElement("div");o.className="notification notification-"+t,o.innerHTML=`
        <i class="fas fa-${"success"===t?"check-circle":"info-circle"}"></i>
        <span>${e}</span>
        <button class="notification-close"><i class="fas fa-times"></i></button>
    `,o.style.cssText=`
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${"success"===t?"#2ecc71":"#3498db"};
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 400px;
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;e=o.querySelector(".notification-close");e.style.cssText=`
        background: none;
        border: none;
        color: white;
        cursor: pointer;
        font-size: 14px;
        opacity: 0.8;
        transition: opacity 0.3s ease;
    `,e.addEventListener("click",()=>{c(o)}),document.body.appendChild(o),setTimeout(()=>{o.style.transform="translateX(0)"},100),setTimeout(()=>{c(o)},5e3)}function c(e){e.style.transform="translateX(100%)",setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e)},300)}function l(){var e=document.querySelectorAll("img[data-src]");let o=new IntersectionObserver(function(e,t){e.forEach(e=>{e.isIntersecting&&((e=e.target).src=e.dataset.src,e.classList.remove("lazy"),o.unobserve(e))})});e.forEach(e=>{o.observe(e)})}function d(){var e={title:"TableExporter - 表格导出神器",text:"智能识别网页表格，一键导出Excel！支持复杂表格、数据分析必备，让数据处理变得简单高效。",url:window.location.href};navigator.share?navigator.share(e).then(()=>{s("感谢您的分享！","success")}).catch(e=>{u()}):u()}function u(){let e=`TableExporter - 表格导出神器
智能识别网页表格，一键导出Excel！
`+window.location.href;navigator.clipboard?navigator.clipboard.writeText(e).then(()=>{s("分享链接已复制到剪贴板！","success")}).catch(()=>{m(e)}):m(e)}function m(e){let t=document.createElement("div"),o=(t.className="share-modal",t.innerHTML=`
        <div class="share-modal-content">
            <div class="share-modal-header">
                <h3>分享 TableExporter</h3>
                <button class="share-modal-close">&times;</button>
            </div>
            <div class="share-modal-body">
                <p>复制下面的文本分享给朋友：</p>
                <textarea readonly class="share-text">${e}</textarea>
                <div class="share-buttons">
                    <button class="btn btn-primary copy-btn">复制文本</button>
                    <a href="https://weibo.com/intent/tweet?text=${encodeURIComponent(e)}" target="_blank" class="btn btn-secondary">
                        <i class="fab fa-weibo"></i> 分享到微博
                    </a>
                </div>
            </div>
        </div>
    `,document.createElement("style"));o.textContent=`
        .share-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            animation: fadeIn 0.3s ease;
        }
        
        .share-modal-content {
            background: white;
            border-radius: 12px;
            padding: 0;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow: hidden;
            animation: slideUp 0.3s ease;
        }
        
        .share-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .share-modal-header h3 {
            margin: 0;
            color: #333;
        }
        
        .share-modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .share-modal-body {
            padding: 20px;
        }
        
        .share-text {
            width: 100%;
            height: 100px;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            resize: none;
            font-family: inherit;
            margin: 15px 0;
        }
        
        .share-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .copy-btn {
            flex: 1;
            min-width: 120px;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    `,document.head.appendChild(o),document.body.appendChild(t);var e=t.querySelector(".share-modal-close"),n=t.querySelector(".copy-btn");let a=t.querySelector(".share-text");e.addEventListener("click",()=>{document.body.removeChild(t),document.head.removeChild(o)}),t.addEventListener("click",e=>{e.target===t&&(document.body.removeChild(t),document.head.removeChild(o))}),n.addEventListener("click",()=>{a.select(),document.execCommand("copy"),s("文本已复制到剪贴板！","success"),document.body.removeChild(t),document.head.removeChild(o)}),a.select()}document.addEventListener("DOMContentLoaded",function(){e(),t(),o(),n(),i(),r()}),window.addEventListener("load",function(){let e=document.querySelector(".page-loader");e&&(e.style.opacity="0",setTimeout(()=>{e.style.display="none"},300));var t=document.querySelector(".hero-text");let o=document.querySelector(".hero-image");t&&(t.style.animation="fadeInUp 1s ease forwards"),o&&(o.style.animation="fadeInUp 1s ease 0.3s forwards",o.style.opacity="0",setTimeout(()=>{o.style.opacity="1"},300))}),document.addEventListener("keydown",function(e){var t;"Escape"===e.key&&(e=document.querySelector(".nav-menu"),t=document.querySelector(".nav-toggle"),e)&&e.classList.contains("active")&&(e.classList.remove("active"),t.classList.remove("active"))}),window.addEventListener("error",function(e){}),document.addEventListener("DOMContentLoaded",function(){l()}),window.TableExporterSite={showNotification:s,removeNotification:c,shareProject:d},window.shareProject=d;